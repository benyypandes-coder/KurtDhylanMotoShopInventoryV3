# KurtDhylanMotoShopInventoryV3

GitHub repository package for the Kurt Dhylan Moto Shop Inventory Android app.

## Repository layout

```text
KurtDhylanMotoShopInventoryV3/
├── .github/
│   └── workflows/
│       └── build-android.yml
├── KurtDhylanMotoShopInventoryV3_Source.zip
└── README.md
```

The GitHub Actions workflow automatically extracts `KurtDhylanMotoShopInventoryV3_Source.zip`, finds the MAUI `.csproj`, installs the Android MAUI workload, builds a Release APK, and uploads the APK as an Actions artifact.

## Run the workflow

GitHub → Actions → **Build Kurt Dhylan Moto Shop Inventory V3 APK** → **Run workflow**

A push to `main` or `master` also starts the workflow automatically.

## APK artifact

After a successful build:

**Actions → workflow run → Artifacts → `KurtDhylanMotoShopInventoryV3-APK`**

The APK file is named:

`KurtDhylanMotoShopInventoryV3.apk`
