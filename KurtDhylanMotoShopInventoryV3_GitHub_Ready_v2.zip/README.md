# KurtDhylanMotoShopInventoryV3 — GitHub Ready

Upload the contents of this folder to the root of the GitHub repository:

`KurtDhylanMotoShopInventoryV3`

The workflow automatically:
1. Finds `KurtDhylanMotoShopInventoryV3_Source.zip` anywhere in the repository.
2. Extracts it.
3. Finds the `.csproj`.
4. Installs the MAUI Android workload.
5. Restores and publishes the Android APK.
6. Uploads `KurtDhylanMotoShopInventoryV3.apk` as a GitHub Actions artifact.

If the source is already extracted and a `.csproj` exists in the repository, the workflow can also build that directly.
