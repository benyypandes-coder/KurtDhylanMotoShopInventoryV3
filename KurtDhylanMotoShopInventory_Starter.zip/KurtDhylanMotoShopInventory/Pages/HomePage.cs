using KurtDhylanMotoShopInventory.Models;
using KurtDhylanMotoShopInventory.Services;

namespace KurtDhylanMotoShopInventory.Pages;

public class HomePage : ContentPage
{
    readonly InventoryStore _store = new();
    readonly VerticalStackLayout _content = new() { Spacing = 12 };
    readonly Label _productCount = new();
    readonly Label _serviceCount = new();
    readonly Label _stockCount = new();

    public HomePage()
    {
        Title = "Kurt Dhylan Moto Shop";
        BackgroundColor = Color.FromArgb("#0D0D0F");

        var logo = new Image
        {
            Source = "shop_logo.jpg",
            HeightRequest = 170,
            Aspect = Aspect.AspectFit,
            Margin = new Thickness(0, 8, 0, 0)
        };

        var title = new Label
        {
            Text = "KURT DHYLAN MOTO SHOP",
            FontSize = 24,
            FontAttributes = FontAttributes.Bold,
            TextColor = Colors.White,
            HorizontalTextAlignment = TextAlignment.Center
        };

        var subtitle = new Label
        {
            Text = "INVENTORY • PRODUCTS • SERVICES • ORDERS",
            FontSize = 12,
            TextColor = Color.FromArgb("#A9A9B0"),
            HorizontalTextAlignment = TextAlignment.Center
        };

        var stats = new Grid
        {
            ColumnDefinitions =
            {
                new ColumnDefinition(GridLength.Star),
                new ColumnDefinition(GridLength.Star),
                new ColumnDefinition(GridLength.Star)
            },
            ColumnSpacing = 8
        };
        stats.Add(StatCard("PRODUCTS", _productCount), 0, 0);
        stats.Add(StatCard("SERVICES", _serviceCount), 1, 0);
        stats.Add(StatCard("STOCK", _stockCount), 2, 0);

        _content.Add(Section("MAIN MENU"));
        _content.Add(MenuButton("📦  PRODUCTS", async () => await Navigation.PushAsync(new ProductsPage(_store))));
        _content.Add(MenuButton("🔧  SERVICES", async () => await Navigation.PushAsync(new ServicesPage(_store))));
        _content.Add(MenuButton("🛒  CREATE ORDER / CHECKOUT", async () => await Navigation.PushAsync(new OrderPage(_store))));
        _content.Add(MenuButton("🔍  SEARCH INVENTORY", async () => await Navigation.PushAsync(new SearchPage(_store))));

        Content = new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = new Thickness(18, 10),
                Spacing = 10,
                Children = { logo, title, subtitle, stats, _content }
            }
        };

        Appearing += async (_, _) => await RefreshStats();
    }

    static View Section(string text) => new Label
    {
        Text = text,
        TextColor = Color.FromArgb("#E50914"),
        FontAttributes = FontAttributes.Bold,
        FontSize = 13,
        Margin = new Thickness(2, 10, 0, 0)
    };

    static Border StatCard(string label, Label value)
    {
        value.Text = "0";
        value.TextColor = Colors.White;
        value.FontSize = 22;
        value.FontAttributes = FontAttributes.Bold;
        value.HorizontalTextAlignment = TextAlignment.Center;

        return new Border
        {
            BackgroundColor = Color.FromArgb("#17171A"),
            Stroke = Color.FromArgb("#303036"),
            StrokeShape = new RoundRectangle { CornerRadius = 14 },
            Padding = 8,
            Content = new VerticalStackLayout
            {
                Spacing = 2,
                Children =
                {
                    value,
                    new Label { Text = label, TextColor = Color.FromArgb("#A9A9B0"), FontSize = 9, HorizontalTextAlignment = TextAlignment.Center }
                }
            }
        };
    }

    static Button MenuButton(string text, Func<Task> action)
    {
        var b = new Button
        {
            Text = text,
            HeightRequest = 56,
            CornerRadius = 14,
            BackgroundColor = Color.FromArgb("#E50914"),
            TextColor = Colors.White,
            FontSize = 15,
            FontAttributes = FontAttributes.Bold
        };
        b.Clicked += async (_, _) => await action();
        return b;
    }

    async Task RefreshStats()
    {
        var p = await _store.LoadProductsAsync();
        var s = await _store.LoadServicesAsync();
        _productCount.Text = p.Count.ToString();
        _serviceCount.Text = s.Count.ToString();
        _stockCount.Text = p.Sum(x => x.Stock).ToString();
    }
}
