# KurtDhylanMotoShopInventoryV3 - GitHub Upload Package

IMPORTANT:
Do NOT upload this outer ZIP itself as the only file in GitHub.

1. Download this ZIP.
2. Extract it on your phone/PC.
3. Open the extracted `KurtDhylanMotoShopInventoryV3_GitHub_Package` folder.
4. Upload ALL of its contents to the ROOT of your GitHub repository:
   `KurtDhylanMotoShopInventoryV3`

The repository should contain:

.github/workflows/build-android.yml
KurtDhylanMotoShopInventoryV3_Source.zip
README.md

The GitHub Actions workflow will automatically extract the Source ZIP, find the .csproj, build the Android APK, and upload the APK as an Actions artifact.
